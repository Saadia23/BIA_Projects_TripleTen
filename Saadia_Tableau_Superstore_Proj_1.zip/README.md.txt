Superstore Returns Analysis Project

Tableau Public Link
[View my dashboard on Tableau Public](https://public.tableau.com/views/TableauProject_17478830969320/Dashboard1?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link)

Project Overview
Part 1: Profit & Losses 
1. The two biggest profit centers are the West region and East region. The biggest loss makers are Central and South regions. 
2. Super store needs to stop selling the following products because their profit is in the negatives: Cubify CubeX 3D Printer Double Head Print, Bush Advantage Collection Racetrack Conference Table, Cisco 9971 IP Video Phone Charcoal, Lexmark MX611dhe Monochrome Laser Printer.  
3. The 3 product subcategories that Superstore should focus on: Accessories, Phones and Copiers. The 3 product subcategories that Superstore should stop selling: Tables, Bookcases and Binders

Part 2: Advertising 
The 3 best states to advertise in is West Virginia, Wisconsin and Wyoming. The best months for each state are the following: 
Washington: March
Indiana: October
Vermont: November

Based on the heat map which showcases the highest average profit, here is how much we should be willing to pay in advertising for each state: 
Washington: 4,692
Indiana: 1,801
Vermont: 238


Part 3.1: Returned Items
The following products have the highest return rate: 
Zebra GK420t Direct Thermal/ Thermal Transfer Printer
Okidata B401 Printer
Hewlett-Packard Deskjet F4180 All0in-One Color Ink-Jet Printer/ copier/ scanner


Part 3.2: Customer Returns
The following customers have the highest return rate: 
Roland Murray
Hilary Holden
Sandra Glassco

Part 3.3: Returned Items
When looking at the average profit vs average return rate for each state, it is recommended for Superstore to take the following actions: 
-Both California and Utah have a high return rate and a  low average profit. It might be best to look into why that is. 
-It is recommended to stop doing business in the following states because of their positive average return rate but a negative average profit rate: Oregon, Tennessee, Ohio, Texas, Pennsylvania, North Carolina. 
-The following states would a good place to continue investing and growing business in due to their low average return rates but high average profit rates: Vermont, Wyoming, District of Columbia and Nevada. 

