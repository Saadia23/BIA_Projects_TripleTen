Tableau Dashboard Link: https://public.tableau.com/views/Book1_17502585543090/Dashboard1?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link

Presentation Link: https://drive.google.com/file/d/1YuG5rX8qTPhRWIH_8p-0WGU6rjP4pcfz/view?usp=sharing